package com.lordjm.pro

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import java.io.File

class MainActivity : Activity() {
    private val green = Color.rgb(18, 140, 96)
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var audioFile: File? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(8, 24, 20))
        }
    }

    private fun text(value: String, size: Float, color: Int = Color.WHITE): TextView =
        TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(4, 12, 4, 12) }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }

    private fun showHome() {
        val layout = base()
        layout.addView(text("LORD JM PRO", 30f))
        layout.addView(text("CHAT  •  VOICE  •  AUDIO STUDIO", 13f, Color.rgb(130, 220, 180)))
        layout.addView(text("Chats", 22f))
        layout.addView(text("Your conversations will appear here. Online messaging needs a secure chat backend setup.", 15f, Color.LTGRAY))
        layout.addView(button("Open Audio Studio") { showStudio() })
        layout.addView(text("Audio Studio", 22f))
        layout.addView(text("Record a voice note on this device and play it back.", 15f, Color.LTGRAY))
        setContentView(layout)
    }

    private fun showStudio() {
        val layout = base()
        layout.addView(text("←  AUDIO STUDIO", 24f).apply { setOnClickListener { showHome() } })
        status = text("Ready to record", 16f, Color.rgb(130, 220, 180))
        layout.addView(status)
        layout.addView(button("● START RECORDING") { startRecording() })
        layout.addView(button("■ STOP RECORDING") { stopRecording() })
        layout.addView(button("▶ PLAY RECORDING") { playRecording() })
        layout.addView(text("Audio controls", 20f))
        layout.addView(text("Loud mic / gain, echo, noise reduction and voice changer are planned for the next audio-engine stage. This starter records a clean voice note first.", 14f, Color.LTGRAY))
        layout.addView(button("Back to Chats") { showHome() })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            status.text = "Allow microphone permission, then try again"
            return
        }
        try {
            player?.release(); player = null
            audioFile = File(cacheDir, "lordjm_voice_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder = r
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(audioFile!!.absolutePath)
            r.prepare()
            r.start()
            status.text = "Recording…"
        } catch (e: Exception) {
            status.text = "Could not start: ${e.localizedMessage ?: "microphone error"}"
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
        }
    }

    private fun stopRecording() {
        try {
            recorder?.stop()
            status.text = "Saved voice note on this device"
        } catch (_: Exception) {
            status.text = "Recording was too short. Try again."
        } finally {
            recorder?.release()
            recorder = null
        }
    }

    private fun playRecording() {
        val file = audioFile
        if (file == null || !file.exists()) { status.text = "Record a voice note first"; return }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { it.release(); player = null }
                prepare()
                start()
            }
            status.text = "Playing voice note…"
        } catch (e: Exception) {
            status.text = "Playback error: ${e.localizedMessage}"
        }
    }

    override fun onDestroy() {
        try { recorder?.release() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
